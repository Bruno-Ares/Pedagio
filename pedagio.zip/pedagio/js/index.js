const placa = document.querySelector("#inputPlaca")
const horaEntrada = document.querySelector("#inputHoraEntrada")
const horaSaida = document.querySelector("#inputHoraSaida")

const btnCalcular = document.querySelector("#btnCalcular")
const btnLimpar = document.querySelector("#btnLimpar")
const btnSessao = document.querySelector("#btnSessao")
const btnIniciarSessao = document.querySelector("#btnIniciarSessao")
const btnRelatorio = document.querySelector("#btnRelatorio")

const relatorio = document.querySelector("#relatorio")
const ticket = document.querySelector("#ticket")
const pedagio = document.querySelector("#pedagio")
const containerPedagio = document.querySelector("#containerPedagio")

const distancia = 120
const taxa = 20
var dataInicio, dataFim = 0
var somaPedagio = 0
var media = 0
var cont = 0
var maiorVel = 0
var menorVel = -1
var maiorPlaca, menorPlaca = ""


function diffHora (entrada, saida)
{
    var e = entrada.split(":")
    eMin = +e[1] + e[0]*60 //s[1] possui os minutos, s[0] possui as horas

    var  s = saida.split(":") //divide o tempo obtido em um array
    sMin = +s[1] + s[0]*60

    diff = sMin - eMin
    if (diff < 0) //caso a diferença seja negativa, a formula muda para considerar a mudanca de dia
    {
        diff = sMin + (24*60 - eMin)
    }

    return diff
}
//Calcular o pedágio
btnCalcular.addEventListener("click", () =>{

    btnRelatorio.classList.remove("invisivel")

    let tempo = diffHora(horaEntrada.value, horaSaida.value)
    let velMedia
    if (tempo == 0){

        velMedia = 0

    } else{velMedia = parseFloat(distancia/(tempo/60))}

   

    let pedagio

    if (velMedia <= 60) {pedagio = taxa * 0.85}
    else if (velMedia <= 100) {pedagio = taxa * 0.90}
    else {pedagio = taxa}

    somaPedagio += pedagio
    cont++
    media += velMedia

    if (maiorVel < velMedia) {maiorVel = velMedia}
    if ((menorVel > velMedia) || menorVel == -1) {menorVel = velMedia}


    document.getElementById("divPlaca").innerHTML = placa.value
    document.getElementById("divEntrada").innerHTML = horaEntrada.value
    document.getElementById("divSaida").innerHTML = horaSaida.value
    document.getElementById("divVelocidade").innerHTML = velMedia.toFixed(2).toString().replace(".", ",") + " km/h"
    document.getElementById("divPedagio").innerHTML = "R$ " + pedagio.toFixed(2).toString().replace(".", ",")

})
//Botão para limpar os campos
btnLimpar.addEventListener("click", () =>{
    placa.value = ""
    horaEntrada.value = ""
    horaSaida.value = ""
})

//Iniciar a sessão
btnIniciarSessao.addEventListener("click", () =>{

    dataInicio = new Date() //Pega a data de ínicio
    //console.log(dataInicio)
    const formulario = document.querySelector("#formulario")
    formulario.classList.remove("invisivel")
    btnSessao.classList.remove("invisivel")
    btnIniciarSessao.classList.add("invisivel")
    
    
})

btnRelatorio.addEventListener("click", () =>{
    relatorio.classList.add("invisivel")
    ticket.classList.remove("invisivel")
    const tituloResultados = document.querySelector("#tituloResultados")
    tituloResultados.classList.remove("invisivel")
    
    window.print();
})


btnSessao.addEventListener("click", () =>{

    media = media / cont

    document.getElementById("menorVelocidade").innerHTML = menorVel.toFixed(3).toString().replace(".", ",")  + " km/h"

    document.getElementById("maiorVelocidade").innerHTML = maiorVel.toFixed(3).toString().replace(".", ",")  + " km/h"

    document.getElementById("mediaVelocidade").innerHTML = media.toFixed(3).toString().replace(".", ",") + " km/h"

    document.getElementById("totalValor").innerHTML = "R$ " + somaPedagio.toFixed(2).toString().replace(".", ",")
    
    data = new Date(dataInicio).toLocaleString('pt-BR', {hour12: false})
    document.getElementById("inicioProcesso").innerHTML = data


    data = new Date().toLocaleString('pt-BR', {hour12: false})
    document.getElementById("fimProcesso").innerHTML = data

    media = 0
    cont = 0
    somaPedagio = 0
    maiorVel = 0
    menorVel = 0


    //Faz com que só apareça o relatório
    relatorio.classList.remove("invisivel")
    containerPedagio.classList.add("invisivel")
    pedagio.classList.add("invisivel")
    ticket.classList.add("invisivel")

    window.print(); //Imprime a tela
    //Volta com o ticket e o pedágio, além do botão de iniciar sessão
    relatorio.classList.add("invisivel")
    containerPedagio.classList.remove("invisivel")
    pedagio.classList.remove("invisivel")
    ticket.classList.remove("invisivel")

    btnIniciarSessao.classList.remove("invisivel")
    formulario.classList.add("invisivel")
    btnSessao.classList.add("invisivel")

    delete carros.velMedia
    delete carros.placa
    delete carros.pedagio


})

